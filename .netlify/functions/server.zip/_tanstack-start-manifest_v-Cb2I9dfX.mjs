//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Cb2I9dfX.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/mykey/pocket-studio-booking-10a2c4c2/src/routes/__root.tsx",
		children: [
			"/",
			"/blog",
			"/book",
			"/classic",
			"/mobile",
			"/privacy",
			"/studio",
			"/terms",
			"/api/travel-fee",
			"/services/$slug"
		],
		preloads: ["/assets/index-DkpXGiuJ.js", "/assets/link-Cgu-qitC.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DkpXGiuJ.js"
		} }]
	},
	"/": {
		filePath: "/home/mykey/pocket-studio-booking-10a2c4c2/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-xFrrtE9e.js",
			"/assets/EmergencyModal-BKD9aJMI.js",
			"/assets/ReadingModeToggle-BLwMFXDr.js"
		]
	},
	"/blog": {
		filePath: "/home/mykey/pocket-studio-booking-10a2c4c2/src/routes/blog.tsx",
		children: ["/blog/$slug"],
		preloads: ["/assets/blog-Bt9KKWfY.js", "/assets/ReadingModeToggle-BLwMFXDr.js"]
	},
	"/book": {
		filePath: "/home/mykey/pocket-studio-booking-10a2c4c2/src/routes/book.tsx",
		children: void 0,
		preloads: ["/assets/book-fz-lqLMN.js", "/assets/ReadingModeToggle-BLwMFXDr.js"]
	},
	"/classic": {
		filePath: "/home/mykey/pocket-studio-booking-10a2c4c2/src/routes/classic.tsx",
		children: void 0,
		preloads: ["/assets/classic-D_hAh_iq.js"]
	},
	"/mobile": {
		filePath: "/home/mykey/pocket-studio-booking-10a2c4c2/src/routes/mobile.tsx",
		children: void 0,
		preloads: ["/assets/mobile-DkQ9EAaj.js", "/assets/EmergencyModal-BKD9aJMI.js"]
	},
	"/privacy": {
		filePath: "/home/mykey/pocket-studio-booking-10a2c4c2/src/routes/privacy.tsx",
		children: void 0,
		preloads: ["/assets/privacy-5cIElOJd.js", "/assets/LegalLayout-DM6xn-Y_.js"]
	},
	"/studio": {
		filePath: "/home/mykey/pocket-studio-booking-10a2c4c2/src/routes/studio.tsx",
		children: void 0,
		preloads: ["/assets/studio-Tmsdyeov.js"]
	},
	"/terms": {
		filePath: "/home/mykey/pocket-studio-booking-10a2c4c2/src/routes/terms.tsx",
		children: void 0,
		preloads: ["/assets/terms-_Y5ZjOAz.js", "/assets/LegalLayout-DM6xn-Y_.js"]
	},
	"/blog/$slug": {
		filePath: "/home/mykey/pocket-studio-booking-10a2c4c2/src/routes/blog.$slug.tsx",
		children: void 0,
		preloads: ["/assets/blog._slug-BTAGh-JE.js", "/assets/blog._slug-tZEjJzQq.js"]
	},
	"/services/$slug": {
		filePath: "/home/mykey/pocket-studio-booking-10a2c4c2/src/routes/services.$slug.tsx",
		children: void 0,
		preloads: ["/assets/services._slug-DQXAMf1e.js", "/assets/ReadingModeToggle-BLwMFXDr.js"]
	}
} });
//#endregion
export { tsrStartManifest };
